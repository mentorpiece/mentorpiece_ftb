window.onload = function() {
  //<editor-fold desc="Changeable Configuration Block">

  // the following lines will be replaced by docker/configurator, when it runs in a docker-container
  window.ui = SwaggerUIBundle({
    url: "../api-docs.json",
    dom_id: '#swagger-ui',
    deepLinking: true,
    presets: [
      SwaggerUIBundle.presets.apis,
      SwaggerUIStandalonePreset
    ],
    plugins: [
      SwaggerUIBundle.plugins.DownloadUrl
    ],
    layout: "StandaloneLayout" ,

  "configUrl" : "/v3/api-docs/swagger-config",
  "docExpansion" : "none",
  "filter" : "true",
  "operationsSorter" : "method",
  "tagsSorter" : "alpha",
  "validatorUrl" : ""

  });

  //</editor-fold>
};
